package com.floreantpos.model;

import com.floreantpos.model.base.BaseCustomPayment;

public class CustomPayment extends BaseCustomPayment {
	private static final long serialVersionUID = 1L;

	/*[CONSTRUCTOR MARKER BEGIN]*/
	public CustomPayment() {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public CustomPayment(java.lang.Integer id) {
		super(id);
	}

	/*[CONSTRUCTOR MARKER END]*/

}