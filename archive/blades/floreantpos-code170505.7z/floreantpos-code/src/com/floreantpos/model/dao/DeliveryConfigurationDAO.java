package com.floreantpos.model.dao;

import com.floreantpos.model.dao.BaseDeliveryConfigurationDAO;


public class DeliveryConfigurationDAO extends BaseDeliveryConfigurationDAO {

	/**
	 * Default constructor.  Can be used in place of getInstance()
	 */
	public DeliveryConfigurationDAO () {}


}