package com.floreantpos.model;

import com.floreantpos.model.base.BaseEmployeeInOutHistory;



public class EmployeeInOutHistory extends BaseEmployeeInOutHistory {
	private static final long serialVersionUID = 1L;

	public EmployeeInOutHistory () {
		super();
	}

	public EmployeeInOutHistory (java.lang.Integer id) {
		super(id);
	}

}