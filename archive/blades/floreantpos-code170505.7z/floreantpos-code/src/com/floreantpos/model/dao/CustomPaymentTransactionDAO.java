package com.floreantpos.model.dao;

import com.floreantpos.model.dao.BaseCustomPaymentTransactionDAO;

public class CustomPaymentTransactionDAO extends BaseCustomPaymentTransactionDAO {

	/**
	 * Default constructor.  Can be used in place of getInstance()
	 */
	public CustomPaymentTransactionDAO() {
	}
}