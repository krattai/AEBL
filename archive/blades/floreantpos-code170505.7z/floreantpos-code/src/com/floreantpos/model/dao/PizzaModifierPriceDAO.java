package com.floreantpos.model.dao;

import com.floreantpos.model.dao.BasePizzaModifierPriceDAO;


public class PizzaModifierPriceDAO extends BasePizzaModifierPriceDAO {

	/**
	 * Default constructor.  Can be used in place of getInstance()
	 */
	public PizzaModifierPriceDAO () {}


}