package com.floreantpos.model;

import com.floreantpos.model.base.BasePizzaModifierPrice;



public class PizzaModifierPrice extends BasePizzaModifierPrice {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public PizzaModifierPrice () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public PizzaModifierPrice (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}