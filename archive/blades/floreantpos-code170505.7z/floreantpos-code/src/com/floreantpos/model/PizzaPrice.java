package com.floreantpos.model;

import com.floreantpos.model.base.BasePizzaPrice;



public class PizzaPrice extends BasePizzaPrice {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public PizzaPrice () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public PizzaPrice (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}