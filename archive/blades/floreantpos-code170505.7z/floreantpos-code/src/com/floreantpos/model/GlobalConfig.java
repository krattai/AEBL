package com.floreantpos.model;

import com.floreantpos.model.base.BaseGlobalConfig;

public class GlobalConfig extends BaseGlobalConfig {
	private static final long serialVersionUID = 1L;

	public static final String MAP_API_KEY = "map api key";

	public GlobalConfig() {
		super();
	}
}