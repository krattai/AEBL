package com.floreantpos.model;

import com.floreantpos.model.base.BaseTerminalPrinters;



public class TerminalPrinters extends BaseTerminalPrinters {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public TerminalPrinters () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public TerminalPrinters (java.lang.Integer id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}