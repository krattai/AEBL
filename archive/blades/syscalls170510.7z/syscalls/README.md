syscalls
========

syscalls is not a blade, but it is great reference code and the blade folder was the best place to add this code.

The original git repository for this code is:

https://github.com/subogero/syscalls
