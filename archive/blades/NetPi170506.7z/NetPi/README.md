# <img src="http://blamethenetwork.com/wp-content/uploads/2015/03/analyzestealthwallpaper.jpg" />
# NetPi Network Analyzer - A RaspberryPi Project
NetPi Network Analyzer based on Raspberry Pi b+/2 hardware
#########
Visit the project website at http://www.blamethenetwork.com/netpi
#########
Contribute code to any of the scripts available, and request a pull. I will audit to ensure pull removes bugs or increases functionality. Report bugs on the website and I will work to resolve them.
#########
Software is being released GNU GPLv3. I only ask the work is attributed accordingly. All content contributors will be listed on the site and here for their work. A donation for the overall project will be accepted and appreciated to help support working hours put into development. Look forward to future open projects from BlameTheNetwork.com !
#########
#########
Thank you for reading, enjoy the project and share!
