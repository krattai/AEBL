wpa_gui
exit
