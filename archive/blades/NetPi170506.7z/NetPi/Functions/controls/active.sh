chromium-browser --app=http://127.0.0.2/netpi/active/index.php
