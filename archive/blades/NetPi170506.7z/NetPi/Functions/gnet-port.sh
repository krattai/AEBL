# Port Scan Function
# Starts Gnome-Nettool, followed by on screen keyboard.
gnome-nettool -s 127.0.0.1 &
matchbox-keyboard extended &
exit
