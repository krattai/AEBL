# Interface Details Function
# Starts Gnome-Nettool in default mode to view interfaces.
gnome-nettool &
exit
