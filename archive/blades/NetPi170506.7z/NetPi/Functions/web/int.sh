#!/bin/sh
/sbin/ifconfig
