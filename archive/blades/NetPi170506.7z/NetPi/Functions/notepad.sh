# Notepad Function
# Starts Text Editor, followed by on screen keyboard.
leafpad &
matchbox-keyboard extended &
exit
