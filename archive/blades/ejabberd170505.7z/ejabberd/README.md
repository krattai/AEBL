This is a snapshot of the ejabberd github project taken on Sep. 8/2014

https://github.com/processone/ejabberd

This reference code is included because it was actually tested, working to pass messages.  It has been written in Erlang and as such, is not generally a desired framework, although it could be converted to Go if the jabberd2 framework can not be made to work.
