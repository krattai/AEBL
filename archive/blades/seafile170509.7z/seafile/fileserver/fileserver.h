#ifndef SEAFILE_FILESERVER_H
#define SEAFILE_FILESERVER_H

extern SeafileSession *seaf;

#endif // SEAFILE_FILESERVER_H
