#ifndef CLIENT_MIGRATE_H
#define CLIENT_MIGRATE_H

int
migrate_client_v0_repos ();

#endif
