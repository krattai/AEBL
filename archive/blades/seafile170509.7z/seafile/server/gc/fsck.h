#ifndef SEAF_FSCK_H
#define SEAF_FSCK_H

int
seaf_fsck (GList *repo_id_list, gboolean dry_run, gboolean strict);

#endif
