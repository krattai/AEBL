terra vista
===========

Terra Vista is an old, 1996 era VRML virtual world environment.

For many reasons, it is likely a timely opportunity to revisit and re-vitalize Terra Vista due to technology advances and public awareness and acceptance.

The Terra Vista blade should provide the AEBL appliance to host a VRML wrl that is unique for that specific appliance and will integrate into other wrls.

It should also become the starting point for the appliance owner to enter into and then navigate through the wrl and into other's, as desired.
