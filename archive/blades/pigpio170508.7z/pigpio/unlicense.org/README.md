Unlicense.org
=============

This is the [Markdoc](http://markdoc.org/) repository for [Unlicense.org](http://unlicense.org/).

All material in this repository is in the public domain.
