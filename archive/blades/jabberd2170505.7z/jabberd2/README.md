This is a snapshot of the jabberd2 github project taken on Sep. 8/2014

https://github.com/jabberd2/jabberd2
