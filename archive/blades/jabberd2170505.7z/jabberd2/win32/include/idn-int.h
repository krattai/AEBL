#define LOCALEDIR "."
#include "config.h"
#include "ac-stdint.h"
