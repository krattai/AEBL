<?php
$TRANSLATIONS = array(
"Location" => "Loco",
"Region" => "Region",
"Username" => "Nomine de usator",
"Password" => "Contrasigno",
"Share" => "Compartir",
"URL" => "URL",
"Personal" => "Personal",
"Name" => "Nomine",
"Folder name" => "Nomine de dossier",
"Delete" => "Deler"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
