<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "გთხოვთ მიუთითოთ Dropbox აპლიკაციის გასაღები და კოდი.",
"External storage" => "ექსტერნალ საცავი",
"Location" => "ადგილმდებარეობა",
"Port" => "პორტი",
"Region" => "რეგიონი",
"Host" => "ჰოსტი",
"Username" => "მომხმარებლის სახელი",
"Password" => "პაროლი",
"Share" => "გაზიარება",
"URL" => "URL",
"Access granted" => "დაშვება მინიჭებულია",
"Error configuring Dropbox storage" => "შეცდომა Dropbox საცავის კონფიგურირების დროს",
"Grant access" => "დაშვების მინიჭება",
"Error configuring Google Drive storage" => "შეცდომა Google Drive საცავის კონფიგურირების დროს",
"Personal" => "პირადი",
"Name" => "სახელი",
"External Storage" => "ექსტერნალ საცავი",
"Folder name" => "ფოლდერის სახელი",
"Configuration" => "კონფიგურაცია",
"Add storage" => "საცავის დამატება",
"Delete" => "წაშლა",
"Enable User External Storage" => "მომხმარებლის ექსტერნალ საცავის აქტივირება"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
