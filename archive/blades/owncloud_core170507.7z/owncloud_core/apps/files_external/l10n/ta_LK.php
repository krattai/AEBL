<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "தயவுசெய்து ஒரு செல்லுபடியான Dropbox செயலி சாவி மற்றும் இரகசியத்தை வழங்குக. ",
"Location" => "இடம்",
"Port" => "துறை ",
"Region" => "பிரதேசம்",
"Host" => "ஓம்புனர்",
"Username" => "பயனாளர் பெயர்",
"Password" => "கடவுச்சொல்",
"Share" => "பகிர்வு",
"URL" => "URL",
"Access granted" => "அனுமதி வழங்கப்பட்டது",
"Error configuring Dropbox storage" => "Dropbox சேமிப்பை தகவமைப்பதில் வழு",
"Grant access" => "அனுமதியை வழங்கல்",
"Error configuring Google Drive storage" => "Google இயக்க சேமிப்பகத்தை தகமைப்பதில் வழு",
"Personal" => "தனிப்பட்ட",
"Name" => "பெயர்",
"External Storage" => "வெளி சேமிப்பு",
"Folder name" => "கோப்புறை பெயர்",
"Configuration" => "தகவமைப்பு",
"Delete" => "நீக்குக",
"Enable User External Storage" => "பயனாளர் வெளி சேமிப்பை இயலுமைப்படுத்துக"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
