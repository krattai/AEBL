<?php
$TRANSLATIONS = array(
"Location" => "kokapena",
"Personal" => "Pertsonala",
"Delete" => "Ezabatu"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
