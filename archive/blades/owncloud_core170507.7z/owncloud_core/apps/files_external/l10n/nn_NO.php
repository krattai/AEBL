<?php
$TRANSLATIONS = array(
"Location" => "Stad",
"Region" => "Region/fylke",
"Host" => "Tenar",
"Username" => "Brukarnamn",
"Password" => "Passord",
"Share" => "Del",
"URL" => "Nettstad",
"Personal" => "Personleg",
"Name" => "Namn",
"Folder name" => "Mappenamn",
"Configuration" => "Innstillingar",
"Delete" => "Slett"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
