<?php
$TRANSLATIONS = array(
"Location" => "شوێن",
"Username" => "ناوی به‌کارهێنه‌ر",
"Password" => "وشەی تێپەربو",
"Share" => "هاوبەشی کردن",
"URL" => "ناونیشانی به‌سته‌ر",
"Name" => "ناو",
"Folder name" => "ناوی بوخچه"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
