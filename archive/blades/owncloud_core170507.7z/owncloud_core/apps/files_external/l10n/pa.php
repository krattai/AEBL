<?php
$TRANSLATIONS = array(
"Username" => "ਯੂਜ਼ਰ-ਨਾਂ",
"Password" => "ਪਾਸਵਰ",
"Share" => "ਸਾਂਝਾ ਕਰੋ",
"Delete" => "ਹਟਾਓ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
