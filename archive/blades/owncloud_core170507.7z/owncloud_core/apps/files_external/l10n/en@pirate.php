<?php
$TRANSLATIONS = array(
"Password" => "Secret Code"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
