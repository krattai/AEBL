<?php
$TRANSLATIONS = array(
"Location" => "Lokasi",
"Region" => "Wilayah",
"Username" => "Nama pengguna",
"Password" => "Kata laluan",
"Share" => "Kongsi",
"URL" => "URL",
"Personal" => "Peribadi",
"Name" => "Nama",
"Delete" => "Padam"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
