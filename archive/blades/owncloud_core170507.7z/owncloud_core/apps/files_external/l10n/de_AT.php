<?php
$TRANSLATIONS = array(
"Location" => "Ort",
"Port" => "Port",
"Host" => "Host",
"Password" => "Passwort",
"Share" => "Freigeben",
"Personal" => "Persönlich",
"Delete" => "Löschen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
