<?php
$TRANSLATIONS = array(
"Username" => "Usuario",
"Password" => "Clave",
"Share" => "Compartir",
"Personal" => "Personal",
"Folder name" => "Nombre del directorio"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
