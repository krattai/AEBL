<?php
$TRANSLATIONS = array(
"Location" => "مقام",
"Username" => "یوزر نیم",
"Password" => "پاسورڈ",
"Share" => "تقسیم",
"URL" => "یو ار ایل",
"Personal" => "شخصی",
"Name" => "اسم",
"Delete" => "حذف کریں"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
