<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "Xin vui lòng cung cấp một ứng dụng Dropbox hợp lệ và mã bí mật.",
"External storage" => "Lưu trữ ngoài",
"Location" => "Vị trí",
"Port" => "Cổng",
"Region" => "Vùng/miền",
"Host" => "Máy chủ",
"Username" => "Tên đăng nhập",
"Password" => "Mật khẩu",
"Share" => "Chia sẻ",
"URL" => "URL",
"Access granted" => "Đã cấp quyền truy cập",
"Error configuring Dropbox storage" => "Lỗi cấu hình lưu trữ Dropbox ",
"Grant access" => "Cấp quyền truy cập",
"Error configuring Google Drive storage" => "Lỗi cấu hình lưu trữ Google Drive",
"Personal" => "Cá nhân",
"Name" => "Tên",
"External Storage" => "Lưu trữ ngoài",
"Folder name" => "Tên thư mục",
"Configuration" => "Cấu hình",
"Add storage" => "Thêm bộ nhớ",
"Delete" => "Xóa",
"Enable User External Storage" => "Kích hoạt tính năng lưu trữ ngoài"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
