<?php
$TRANSLATIONS = array(
"Location" => "Plaça",
"Username" => "Non d'usancièr",
"Password" => "Senhal",
"Share" => "Parteja",
"URL" => "URL",
"Personal" => "Personal",
"Name" => "Nom",
"Delete" => "Escafa"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
