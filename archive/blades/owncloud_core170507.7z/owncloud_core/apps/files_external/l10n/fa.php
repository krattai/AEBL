<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "لطفا یک کلید و کد امنیتی صحیح دراپ باکس وارد کنید.",
"External storage" => "حافظه خارجی",
"Location" => "محل",
"Port" => "درگاه",
"Region" => "ناحیه",
"Host" => "میزبانی",
"Username" => "نام کاربری",
"Password" => "گذرواژه",
"Share" => "اشتراک‌گذاری",
"URL" => "آدرس",
"Access granted" => "مجوز دسترسی صادر شد",
"Error configuring Dropbox storage" => "خطا به هنگام تنظیم فضای دراپ باکس",
"Grant access" => " مجوز اعطا دسترسی",
"Error configuring Google Drive storage" => "خطا به هنگام تنظیم فضای Google Drive",
"Personal" => "شخصی",
"Saved" => "ذخیره شد",
"Name" => "نام",
"External Storage" => "حافظه خارجی",
"Folder name" => "نام پوشه",
"Configuration" => "پیکربندی",
"Add storage" => "اضافه کردن حافظه",
"Delete" => "حذف",
"Enable User External Storage" => "فعال سازی حافظه خارجی کاربر"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
