<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "Bitte tragen Sie einen gültigen Dropbox-App-Key mit Secret ein.",
"External storage" => "Externer Speicher",
"Local" => "Lokal",
"Location" => "Ort",
"Port" => "Port",
"Host" => "Host",
"Username" => "Benutzername",
"Password" => "Passwort",
"Share" => "Freigeben",
"URL" => "URL",
"Access granted" => "Zugriff gestattet",
"Error configuring Dropbox storage" => "Fehler beim Einrichten von Dropbox",
"Grant access" => "Zugriff gestatten",
"Error configuring Google Drive storage" => "Fehler beim Einrichten von Google Drive",
"Personal" => "Persönlich",
"Saved" => "Gespeichert",
"Name" => "Name",
"External Storage" => "Externer Speicher",
"Folder name" => "Ordnername",
"Configuration" => "Konfiguration",
"Add storage" => "Speicher hinzufügen",
"Delete" => "Löschen",
"Enable User External Storage" => "Externen Speicher für Benutzer aktivieren"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
