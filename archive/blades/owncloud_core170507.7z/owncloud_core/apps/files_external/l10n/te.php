<?php
$TRANSLATIONS = array(
"Username" => "వాడుకరి పేరు",
"Password" => "సంకేతపదం",
"Personal" => "వ్యక్తిగతం",
"Name" => "పేరు",
"Folder name" => "సంచయం పేరు",
"Delete" => "తొలగించు"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
