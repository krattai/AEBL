<?php
$TRANSLATIONS = array(
"Delete" => "Ջնջել"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
