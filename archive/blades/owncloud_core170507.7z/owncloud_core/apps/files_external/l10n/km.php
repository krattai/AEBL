<?php
$TRANSLATIONS = array(
"External storage" => "ឃ្លាំងផ្ទុក​ខាងក្រៅ",
"Location" => "ទីតាំង",
"Port" => "ច្រក",
"Host" => "ម៉ាស៊ីន​ផ្ទុក",
"Username" => "ឈ្មោះ​អ្នកប្រើ",
"Password" => "ពាក្យសម្ងាត់",
"Share" => "ចែក​រំលែក",
"URL" => "URL",
"Access granted" => "បាន​ទទួល​សិទ្ធិ​ចូល",
"Error configuring Dropbox storage" => "កំហុស​ការ​កំណត់​សណ្ឋាន​នៃ​ឃ្លាំងផ្ទុក Dropbox",
"Grant access" => "ទទួល​សិទ្ធិ​ចូល",
"Personal" => "ផ្ទាល់​ខ្លួន",
"Saved" => "បាន​រក្សាទុក",
"Name" => "ឈ្មោះ",
"External Storage" => "ឃ្លាំងផ្ទុក​ខាងក្រៅ",
"Folder name" => "ឈ្មោះ​ថត",
"Configuration" => "ការ​កំណត់​សណ្ឋាន",
"Add storage" => "បន្ថែម​ឃ្លាំងផ្ទុក",
"Delete" => "លុប"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
