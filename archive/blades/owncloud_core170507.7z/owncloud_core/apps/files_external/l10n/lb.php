<?php
$TRANSLATIONS = array(
"Location" => "Uert",
"Region" => "Regioun",
"Host" => "Host",
"Username" => "Benotzernumm",
"Password" => "Passwuert",
"Share" => "Deelen",
"URL" => "URL",
"Personal" => "Perséinlech",
"Name" => "Numm",
"Folder name" => "Dossiers Numm:",
"Delete" => "Läschen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
