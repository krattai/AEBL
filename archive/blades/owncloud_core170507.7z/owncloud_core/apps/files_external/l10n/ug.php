<?php
$TRANSLATIONS = array(
"External storage" => "سىرتقى ساقلىغۇچ",
"Location" => "ئورنى",
"Port" => "ئېغىز",
"Host" => "باش ئاپپارات",
"Username" => "ئىشلەتكۈچى ئاتى",
"Password" => "ئىم",
"Share" => "ھەمبەھىر",
"URL" => "URL",
"Personal" => "شەخسىي",
"Name" => "ئاتى",
"Folder name" => "قىسقۇچ ئاتى",
"Configuration" => "سەپلىمە",
"Delete" => "ئۆچۈر"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
