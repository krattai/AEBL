<?php
$TRANSLATIONS = array(
"Port" => "連接埠",
"Username" => "用戶名稱",
"Password" => "密碼",
"Share" => "分享",
"URL" => "網址",
"Personal" => "個人",
"Saved" => "已儲存",
"Name" => "名稱",
"Folder name" => "資料夾名稱",
"Delete" => "刪除"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
