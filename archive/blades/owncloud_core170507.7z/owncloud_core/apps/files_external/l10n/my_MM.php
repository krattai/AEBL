<?php
$TRANSLATIONS = array(
"Location" => "တည်နေရာ",
"Username" => "သုံးစွဲသူအမည်",
"Password" => "စကားဝှက်"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
