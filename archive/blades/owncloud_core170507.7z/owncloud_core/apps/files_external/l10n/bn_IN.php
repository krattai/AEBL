<?php
$TRANSLATIONS = array(
"Host" => "হোস্ট",
"Username" => "ইউজারনেম",
"Share" => "শেয়ার",
"URL" => "URL",
"Saved" => "সংরক্ষিত",
"Name" => "নাম",
"Folder name" => "ফোল্ডারের নাম",
"Delete" => "মুছে ফেলা"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
