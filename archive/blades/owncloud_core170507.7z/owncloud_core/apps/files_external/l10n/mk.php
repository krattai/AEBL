<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "Ве молам доставите валиден Dropbox клуч и тајна лозинка.",
"Local" => "Локален",
"Location" => "Локација",
"Port" => "Порта",
"Region" => "Регион",
"Host" => "Домаќин",
"Username" => "Корисничко име",
"Password" => "Лозинка",
"Share" => "Сподели",
"URL" => "Адреса",
"Access granted" => "Пристапот е дозволен",
"Error configuring Dropbox storage" => "Грешка при конфигурација на Dropbox",
"Grant access" => "Дозволи пристап",
"Error configuring Google Drive storage" => "Грешка при конфигурација на Google Drive",
"Personal" => "Лично",
"Saved" => "Снимено",
"Name" => "Име",
"External Storage" => "Надворешно складиште",
"Folder name" => "Име на папка",
"Configuration" => "Конфигурација",
"Delete" => "Избриши",
"Enable User External Storage" => "Овозможи надворешни за корисници"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
