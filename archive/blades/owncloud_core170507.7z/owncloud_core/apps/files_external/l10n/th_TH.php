<?php
$TRANSLATIONS = array(
"Please provide a valid Dropbox app key and secret." => "กรุณากรอกรหัส app key ของ Dropbox และรหัสลับ",
"Location" => "ตำแหน่งที่อยู่",
"Port" => "พอร์ต",
"Region" => "พื้นที่",
"Host" => "โฮสต์",
"Username" => "ชื่อผู้ใช้งาน",
"Password" => "รหัสผ่าน",
"Share" => "แชร์",
"URL" => "URL",
"Access granted" => "การเข้าถึงได้รับอนุญาตแล้ว",
"Error configuring Dropbox storage" => "เกิดข้อผิดพลาดในการกำหนดค่าพื้นที่จัดเก็บข้อมูล Dropbox",
"Grant access" => "อนุญาตให้เข้าถึงได้",
"Error configuring Google Drive storage" => "เกิดข้อผิดพลาดในการกำหนดค่าการจัดเก็บข้อมูลในพื้นที่ของ Google Drive",
"Personal" => "ส่วนตัว",
"Name" => "ชื่อ",
"External Storage" => "พื้นทีจัดเก็บข้อมูลจากภายนอก",
"Folder name" => "ชื่อโฟลเดอร์",
"Configuration" => "การกำหนดค่า",
"Delete" => "ลบ",
"Enable User External Storage" => "เปิดให้มีการใช้พื้นที่จัดเก็บข้อมูลของผู้ใช้งานจากภายนอกได้"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
