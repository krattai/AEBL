<?php
$TRANSLATIONS = array(
"Location" => "Vendndodhja",
"Port" => "Porta",
"Host" => "Pritësi",
"Username" => "Përdoruesi",
"Password" => "fjalëkalim",
"Share" => "Ndaj",
"URL" => "URL-i",
"Personal" => "Personale",
"Saved" => "U ruajt",
"Name" => "Emri",
"Folder name" => "Emri i Skedarit",
"Delete" => "Elimino"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
