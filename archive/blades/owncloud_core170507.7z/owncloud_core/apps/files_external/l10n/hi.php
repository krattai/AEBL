<?php
$TRANSLATIONS = array(
"Username" => "प्रयोक्ता का नाम",
"Password" => "पासवर्ड",
"Share" => "साझा करें",
"Personal" => "यक्तिगत"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
