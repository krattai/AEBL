<?php
$TRANSLATIONS = array(
"Username" => "Gebruikersnaam",
"Password" => "Wagwoord",
"Share" => "Deel",
"Personal" => "Persoonlik"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
