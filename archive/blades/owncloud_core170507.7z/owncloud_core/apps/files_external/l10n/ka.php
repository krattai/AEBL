<?php
$TRANSLATIONS = array(
"Users" => "მომხმარებლები"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
