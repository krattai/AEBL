# import everything to support picklings from old versions.
# thanks drue!
from BTL.bitfield import *