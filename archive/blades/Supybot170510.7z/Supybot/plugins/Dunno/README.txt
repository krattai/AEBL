This plugin allows using of personalized error messages (Dunnos) in place of invalid command 
("Error: qwertyytrewq is not a valid command") error messages.
