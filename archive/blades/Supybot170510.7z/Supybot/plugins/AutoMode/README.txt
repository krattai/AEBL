This plugin automaticly voices/halfops/ops users with #channel,<voice/halfop/op> capability
when they join to the channel.
It will also ban automaticly everyone who is in channel ban list ( @channel ban list ).
