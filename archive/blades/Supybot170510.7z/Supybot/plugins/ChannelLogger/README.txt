This plugin automatically logs the channels where the bot is.
