This plugin allows you to set welcoming messages (heralds) to people who are regognized by the bot
when they join the channel.
