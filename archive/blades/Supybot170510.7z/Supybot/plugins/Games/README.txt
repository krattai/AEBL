This plugin provides some fun games like (Russian) roulette, 8ball, monologue which tells you
how many lines you have spoken without anyone interrupting you, coin and dice.
