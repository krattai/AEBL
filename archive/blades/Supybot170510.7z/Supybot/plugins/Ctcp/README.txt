This plugin gives command "@ctcp version" which returns all CTCP version responses to channel.
It also adds CTCP responses to the bot.
