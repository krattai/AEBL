This plugin keeps factoids in your bot.

To add factoid say
"@something is something" And when you call @something the bot says 
"something is something".

If you want factoid to be in different format say (for example):
"@Hi is <reply> Hello" And when you call @hi the bot says "Hello."

If you want the bot to use /mes with Factoids, that is possible too.
"@test is <action> tests." and everytime when someone calls for "test" the bot answers *bot tests.
