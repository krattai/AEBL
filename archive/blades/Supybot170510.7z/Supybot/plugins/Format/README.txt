This plugin provides commands which change the output format of the bot. For example you can make
the bot to bold something.
