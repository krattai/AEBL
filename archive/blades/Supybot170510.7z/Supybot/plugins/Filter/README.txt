This plugin offers several commands which transform text in some way.
It also provides the capability of using such commands to 'filter'
the output of the bot -- for instance, you could make everything the bot says be
in leetspeak, or Morse code, or any number of other kinds of filters. 
Not very useful, but definitely quite fun :)
