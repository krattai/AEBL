This plugin gives the bot ability to show factoids. It can also show information about how many times
factoid has been called.
