This plugin keeps stats of the channel and returns them with the command channelstats.
