Anonymous allows you to send messages anonymously as the bot. If 
supybot.plugins.Anonymous.allowPrivateTarget is True, you can send messages in query too.

One usage example is to identify the bot with NickServ if it fails to identify for some reason.
