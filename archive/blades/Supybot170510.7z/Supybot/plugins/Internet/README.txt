This plugin provides commands to transform domain into IP address and IP address to domain.
It also provides command to search WHOIS information. This plugin can also return hexips.
