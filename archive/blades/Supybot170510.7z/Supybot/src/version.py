"""stick the various versioning attributes in here, so we only have to change
them once."""
version = '0.84.0-dev'
