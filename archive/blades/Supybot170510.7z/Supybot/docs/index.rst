.. Supybot documentation master file, created by
   sphinx-quickstart on Sat Feb 27 12:42:30 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Supybot's documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 0
   :glob:

   *
   plugins

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

