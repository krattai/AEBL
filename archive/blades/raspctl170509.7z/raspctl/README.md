This is a snapshot of the raspctl bitbucket project taken on Sep. 8/2014

https://bitbucket.org/inedit00/raspctl

raspctl is a http backend information and configuration tool.
