WiringPi
======

WiringPi is not so much a blade as it is a GPIO tool that can be useful for those who wish to extend the functionality of their blades with add on hardware.  WiringPi can allow for the interaction between the AEBL and blade hardware.
