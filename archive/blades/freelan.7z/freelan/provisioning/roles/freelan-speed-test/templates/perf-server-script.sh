#!/bin/bash

iperf -s
