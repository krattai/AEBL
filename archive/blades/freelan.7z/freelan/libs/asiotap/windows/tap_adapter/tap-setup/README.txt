# How-to build the tap-setup binary

- Install the Windows Driver Kit (http://www.microsoft.com/whdc/DevTools/WDK/WDKpkg.mspx)
- Open the proper WDK build environment (depends on the target platform): likely "x86 Free" or "x64 Free".
- Go into this directory
- Type: "build -c"
- Enjoy !
