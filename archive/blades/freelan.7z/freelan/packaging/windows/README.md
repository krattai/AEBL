# Installers

To build the Windows installer, you will need to install the Freelan build tools Python/SCons scripts.

Building an installer on Windows also requires [Inno Setup](http://www.jrsoftware.org/isinfo.php).

You will also need to compile the `tap-setup.exe` tool from `libasiotap/windows/tap_adapter/tap-setup` using the WDK 7.1. You will find detailed instructions inside this directory.
