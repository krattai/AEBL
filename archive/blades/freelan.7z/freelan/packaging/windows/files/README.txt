Thank you for installing FreeLAN !
==================================

Your FreeLAN installation was successful. Congratulations !

Freelan runs as a Windows service transparently in the background. You can look for it in the Control Panel > System and Security > Administrative Tools > Services menu.

There is currently no graphical user interface for FreeLAN: FreeLAN will automatically connect to the configured network when your computer starts and will gracefully disconnect when it shuts down.

By default, the FreeLAN configuration is very simple and should be modified to fit your needs. It's default location is "<FreeLAN installation path>\config\freelan.cfg" which should resolve to "C:\Program Files\FreeLAN\config\freelan.cfg" in most cases. See https://github.com/freelan-developers/freelan-all/wiki for a complete guide about how to do that.
