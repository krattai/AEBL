Docker
======

This folder contains image scripts to build and run FreeLAN on Docker.
