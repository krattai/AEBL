FreeLAN
=======

A Docker image for FreeLAN.

Starts by default without a tap adapter and with the ethernet relay enabled.

You can override the configuration by replacing the configuration file at: `/etc/freelan/freelan.cfg`.
