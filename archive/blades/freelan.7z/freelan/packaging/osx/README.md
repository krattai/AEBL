# Mac OS X Installer

To build the Mac OS X package, just type "scons -u .".

You can also build it from the repository root by typing "scons package".
