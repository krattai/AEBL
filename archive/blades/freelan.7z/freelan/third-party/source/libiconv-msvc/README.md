# libiconv for Visual Studio

This code comes from [codeproject](http://www.codeproject.com/Articles/302012/How-to-Build-libiconv-with-Microsoft-Visual-Studio).

Thanks to [PARK-Youngho](http://www.codeproject.com/script/Membership/View.aspx?mid=3279933) for his amazing work.
