  S(osf1_0, "DEC-KANJI", ei_dec_kanji )
  S(osf1_1, "DECKANJI", ei_dec_kanji )
  S(osf1_2, "DEC-HANYU", ei_dec_hanyu )
  S(osf1_3, "DECHANYU", ei_dec_hanyu )
