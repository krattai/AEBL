150312 - at this time stamp, unsure the exact function of zkernel.  Assumption is currently that it is the core of zmq, but this needs to be verified and this README.md needs to be modified if otherwise.

https://github.com/zeromq/zkernel

ØMQ guide
http://zguide.zeromq.org/page:all
