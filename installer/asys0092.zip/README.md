This directory contains the AEBL core scripts and code.

This is the final code for the basic, core AEBL device version, in this specific version release.  This code should NOT change, only the code in the core directory should be modified for the next patch or release.
