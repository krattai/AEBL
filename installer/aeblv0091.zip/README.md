This directory contains the AEBL base installer scripts.

The casysXXXX.sh script is not encapsultaed in the aeblvXXXX zip file, as it will change from version to version, including mid version, so having this file stand alone and be retrieved at the time of installation, is important, without causing people to download a new base image.
